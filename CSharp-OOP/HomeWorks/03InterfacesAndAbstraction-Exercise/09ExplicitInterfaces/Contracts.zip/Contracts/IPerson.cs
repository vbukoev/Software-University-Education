﻿namespace ExplicitInterfaces.Contracts
{
    public interface IPerson
    {        string Name { get; }
        string Country { get; }
        string GetName();
    }
}
