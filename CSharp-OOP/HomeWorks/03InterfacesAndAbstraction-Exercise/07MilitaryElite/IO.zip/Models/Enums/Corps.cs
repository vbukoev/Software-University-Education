﻿namespace MilitaryElite.Models.Enums
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum Corps
    {
        Airforces = 0,
        Marines = 1,
    }
}
