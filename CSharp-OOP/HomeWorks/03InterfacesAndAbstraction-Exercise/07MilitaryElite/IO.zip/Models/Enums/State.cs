﻿namespace MilitaryElite.Models.Enums
{
    using System;
    using System.Collections.Generic;
    using System.Text;


    public enum State
    {
        inProgress = 0, 
        Finished = 1
    }
}
