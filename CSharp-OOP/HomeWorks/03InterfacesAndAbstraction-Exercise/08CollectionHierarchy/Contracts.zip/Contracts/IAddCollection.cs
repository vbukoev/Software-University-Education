﻿namespace _08CollectionHierarchy.Contracts
{
    public interface IAddCollection
    {
        int Add(string item);
    }
}
