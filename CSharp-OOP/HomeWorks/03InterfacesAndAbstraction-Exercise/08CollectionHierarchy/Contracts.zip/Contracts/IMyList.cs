﻿namespace _08CollectionHierarchy.Contracts
{

    public interface IMyList : IAddRemoveCollection
    {
        int Used { get; }
    }
}
