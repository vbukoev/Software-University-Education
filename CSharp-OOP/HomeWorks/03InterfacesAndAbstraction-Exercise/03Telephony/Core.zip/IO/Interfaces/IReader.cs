﻿namespace Telephony.IO.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public interface IReader
    {
        string ReadLine();
    }
}
