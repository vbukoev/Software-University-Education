﻿namespace BirthdayCelebrations.Models
{
    public class Pet : Mammal
    {
        public Pet(string name, string birthdate) : base(name, birthdate)
        {
        }
    }
}
