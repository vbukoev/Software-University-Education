﻿namespace Vehicles.Contracts
{    
    public interface IBus : IVehicle
    {
        string DriveEmpty(double distance);
    }
}
