﻿namespace WildFarm
{
    using System;
    using WildFarm.Core;

    public class StartUp
    {
        static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
