﻿namespace WildFarm.Contracts
{

    public interface IFeline : IMammal
    {
        string Breed { get; }
    }
}
