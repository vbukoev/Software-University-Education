﻿namespace WildFarm.Contracts
{
    public interface IBird : IAnimal
    {
        double WingSize { get; }
    }
}
