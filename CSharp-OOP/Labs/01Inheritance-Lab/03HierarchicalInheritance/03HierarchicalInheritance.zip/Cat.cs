﻿using Farm;
using System;
using System.Collections.Generic;
using System.Text;

namespace _03HierarchicalInheritance
{
    public class Cat : Animal
    {
        public void Meow()
        {
            Console.WriteLine("meowing…");
        }
    }
}
