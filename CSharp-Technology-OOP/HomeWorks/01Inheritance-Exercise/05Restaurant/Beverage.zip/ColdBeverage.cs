﻿namespace Restaurant
{
    public class ColdBeverage : Beverage
    {
        public ColdBeverage(string name, decimal price, double mililitters) : base(name, price, mililitters)
        {
        }
    }
}
