﻿namespace Restaurant
{
    public class Tea : HotBeverage
    {
        public Tea(string name, decimal price, double mililitters) : base(name, price, mililitters)
        {
        }
    }
}
