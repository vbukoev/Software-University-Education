﻿namespace Restaurant
{
    public class HotBeverage : Beverage
    {
        public HotBeverage(string name, decimal price, double mililitters) : base(name, price, mililitters)
        {
        }
    }
}
