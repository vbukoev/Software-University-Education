﻿using System;

namespace Drones
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           
        }
    }
}
