﻿namespace _09CustomDoublyLinkedList

{
using System;
    public class StartUp
    {
        static void Main(string[] args)
        {
            var list = new CustomDoublyLinkedList<int>();
        }
    }
}