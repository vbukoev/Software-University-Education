﻿using System;

namespace _01DefineAClassPerson
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var first = new Person(20, "Peter");
            var second = new Person(18, "George");
            var third = new Person(43, "Jose");
        }
    }
}
