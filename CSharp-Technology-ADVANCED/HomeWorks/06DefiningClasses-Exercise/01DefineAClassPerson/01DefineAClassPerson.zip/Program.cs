﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person first = new Person(20, "Peter");
            Person second = new Person(18, "George");
            Person third = new Person(43, "Jose");
        }
    }
}
